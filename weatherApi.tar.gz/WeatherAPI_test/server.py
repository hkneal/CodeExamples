from flask import Flask, request, redirect, render_template
import re, config
# create a regular expression object that we can use run operations on
app = Flask(__name__, instance_relative_config=True)

app.config.from_object('config')
# bcrypt = Bcrypt(app)
app.secret_key = "ThisIsSecret!"
# mysql = MySQLConnector(app,'walldb')

@app.route('/', methods=['GET'])
def index():
    print "Inside of root"
    return render_template("index.html")

@app.route('/weather', methods=['POST'])
def weather():
    print "Inside of Weather"
    city = request.form['location']
    apikey = config.APIKEY
    return render_template("weather.html", city=city, apikey=apikey)

app.run(debug=True, port=8080)
