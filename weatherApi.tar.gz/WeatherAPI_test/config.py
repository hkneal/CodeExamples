#Config.py

APIKEY = 'Insert API Key Here'
